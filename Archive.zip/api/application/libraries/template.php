<?php

/**
 * Renders the template
 */
class Template{
    
    private $CI;                            // CI instance
    private $_viewData = array();           // The view data
    private $_viewPath = "";                // The view file path
    
    public function __construct() {
        $this->CI = & get_instance();
    }

    public function setViewData($data = array()){ $this->_viewData = $data; return $this; }
    public function setViewPath($path = ""){ $this->_viewPath = $path; return $this; }
    
    /**
     * Renders the output
     *
     * If a compiledView is provided, it simply uses it. Otherwise it uses the
     * _viewData and _viewPath to first compile the view and the print it.
     * 
     * @param  html $compiledView The compiled view (optional)
     */
    public function render($compiledView = false){

        // Render the header
        $this->CI->load->view('templates/header', array(
            "sidemenu" => $this->CI->load->view('templates/sidemenu', array(), true),
            ));

        // Use a compiled view if provided otherwise compile it youeself
        if ($compiledView !== false)
            $html = $compiledView;
        else
            $html = $this->CI->load->view($this->_viewPath, $this->_viewData, true);
            

        // Render the middle
        $this->CI->load->view('templates/middle', array(
            "htmlContent" => $html));

        // Render the footer
        $this->CI->load->view('templates/footer');
    }

}

?>
