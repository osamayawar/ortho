<div class="list-group">
	<a href="<?php echo base_url();?>patient/add" class="list-group-item"><span class="glyphicon glyphicon-plus-sign" aria-hidden="true"></span> Add New Patient</a>
  	<a href="#" class="list-group-item">Menu Item B</a>
  	<a href="#" class="list-group-item">Menu Item C</a>
  	<a href="#" class="list-group-item">Menu Item D</a>
  	<a href="#" class="list-group-item">Menu Item E</a>
</div>